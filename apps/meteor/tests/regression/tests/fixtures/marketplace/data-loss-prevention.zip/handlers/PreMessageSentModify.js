"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PreMessageSentModifyHandler = void 0;
const uikit_1 = require("@rocket.chat/apps-engine/definition/uikit");
const Settings_1 = require("../config/Settings");
const Rooms_1 = require("../lib/Rooms");
const Rules_1 = require("../lib/Rules");
const Settings_2 = require("../lib/Settings");
const Message_1 = require("../ui/blocks/Message");
class PreMessageSentModifyHandler {
    constructor(app, message, builder, read, http, persis) {
        this.app = app;
        this.message = message;
        this.builder = builder;
        this.read = read;
        this.http = http;
        this.persis = persis;
    }
    async run() {
        const { id: originalMessageId, text, sender: { username: messageSender }, room } = this.message;
        if (!text || !originalMessageId) {
            return this.message;
        }
        const roomIsSafe = await Rooms_1.isRoomSafe(this.read, room);
        if (roomIsSafe) {
            return this.message;
        }
        const { isSafe, newMessageText, matchedRules } = Rules_1.isMessageContentSafe(this.app.rules, text);
        if (isSafe) {
            return this.message;
        }
        const censorOnlySensitiveInfo = await Settings_2.getAppSettingValue(this.read, Settings_1.AppSetting.DLPCensorOnlySensitiveInfo);
        const moderatorRoomTextMsg = await Rooms_1.resolveModeratorRoomTextMsg(this.read, room);
        this.builder.setText('');
        const blocks = [
            await Message_1.blockedMessageTitleBlock(this.app.getID(), this.read),
            Message_1.moreInfoMessageBlock(this.app.getID(), originalMessageId),
        ];
        if (censorOnlySensitiveInfo && newMessageText) {
            blocks.unshift({
                appId: this.app.getID(),
                type: uikit_1.BlockType.SECTION,
                text: {
                    type: uikit_1.TextObjectType.MARKDOWN,
                    text: newMessageText,
                },
            });
        }
        this.builder.addBlocks(blocks);
        let newMessage = this.builder.getMessage();
        newMessage = Object.assign(newMessage, {
            customFields: {
                dlpMessage: {
                    originalMessageId,
                    originalMessage: text,
                    messageSender,
                    moderatorRoomTextMsg,
                    matchedRules,
                },
            },
        });
        return newMessage;
    }
}
exports.PreMessageSentModifyHandler = PreMessageSentModifyHandler;
