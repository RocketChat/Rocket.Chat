"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModerationStatus = exports.ErrorEnum = void 0;
var ErrorEnum;
(function (ErrorEnum) {
    ErrorEnum["ErrorApprovingMessage"] = "Error occurred while approving message. Details:";
    ErrorEnum["ErrorRejectingMessage"] = "Error occurred while rejecting message. Details:";
    ErrorEnum["ErrorOperationFailedMessage"] = "Error occurred while performing the operation";
    ErrorEnum["RoomOrValueUndefined"] = "Error: Action UI Value or Room undefined";
})(ErrorEnum = exports.ErrorEnum || (exports.ErrorEnum = {}));
var ModerationStatus;
(function (ModerationStatus) {
    ModerationStatus["PENDING_APPROVAL"] = "Pending Approval";
    ModerationStatus["REJECTED"] = "Rejected";
    ModerationStatus["APPROVED"] = "Approved";
})(ModerationStatus = exports.ModerationStatus || (exports.ModerationStatus = {}));
