"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActionEnum = exports.BlocksEnum = exports.ACTION_ID = exports.AlertsEnum = void 0;
var AlertsEnum;
(function (AlertsEnum) {
    AlertsEnum["defaultTitle"] = "Data Loss Prevention Notification";
    AlertsEnum["moreInfoModalTitle"] = "DLP - Sensitive Information Detected";
})(AlertsEnum = exports.AlertsEnum || (exports.AlertsEnum = {}));
var ACTION_ID;
(function (ACTION_ID) {
    ACTION_ID["APPROVE"] = "APPROVE";
    ACTION_ID["REJECT"] = "REJECT";
    ACTION_ID["DISMISS"] = "DISMISS";
    ACTION_ID["MORE_INFO"] = "MORE_INFO";
})(ACTION_ID = exports.ACTION_ID || (exports.ACTION_ID = {}));
var BlocksEnum;
(function (BlocksEnum) {
    BlocksEnum["APPROVE"] = "Approve";
    BlocksEnum["REJECT"] = "Reject";
    BlocksEnum["DISMISS"] = "Dismiss";
    BlocksEnum["MORE_INFO"] = "More Info";
    BlocksEnum["CLOSE"] = "Close";
})(BlocksEnum = exports.BlocksEnum || (exports.BlocksEnum = {}));
var ActionEnum;
(function (ActionEnum) {
    ActionEnum["APPROVED"] = "Approved";
    ActionEnum["REJECTED"] = "Rejected";
})(ActionEnum = exports.ActionEnum || (exports.ActionEnum = {}));
