"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settings = exports.ChannelFilterOption = exports.DefaultMessage = exports.AppSetting = void 0;
const settings_1 = require("@rocket.chat/apps-engine/definition/settings");
var AppSetting;
(function (AppSetting) {
    AppSetting["DLPRules"] = "DLP_rules";
    AppSetting["DLPModeratorChannel"] = "DLP_moderator_channel";
    AppSetting["DLPCensorOnlySensitiveInfo"] = "DLP_censor_only_sensitive_info";
    AppSetting["DLPCustomBlockedMessageTitle"] = "DLP_blocked_message_title";
    AppSetting["DLPCustomPendingApprovalMessage"] = "DLP_custom_pending_approval_message";
    AppSetting["DLPCustomRejectedMessage"] = "DLP_custom_rejected_message";
    AppSetting["DLPContentControlType"] = "DLP_content_control_type";
    AppSetting["DLPChannels"] = "DLP_channels";
})(AppSetting = exports.AppSetting || (exports.AppSetting = {}));
var DefaultMessage;
(function (DefaultMessage) {
    DefaultMessage["DEFAULT_BLOCKED_MESSAGE_TITLE"] = "This message was blocked due to sensitive content.";
    DefaultMessage["DEFAULT_PENDING_APPROVAL_MESSAGE"] = "The message has been forwarded to moderators for approval. Once a moderator approves the message, it will be unblocked.";
    DefaultMessage["DEFAULT_REJECTED_MESSAGE"] = "The message has been reviewed and blocked by moderators.";
    DefaultMessage["MORE_INFO_MODAL_BLOCKED_TYPES"] = "The following type(s) of sensitive information were detected inside the message:";
})(DefaultMessage = exports.DefaultMessage || (exports.DefaultMessage = {}));
const rulesInitialValue = `[
	{
		"pattern": "(?:4[0-9]{12}(?:[0-9]{3})?|[25][1-7][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\\d{3})\\d{11})",
		"name": "Credit Card"
	},
	{
		"pattern": "(\\+?\\d{1,3}\\s?)?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}",
		"name": "Phone number"
	},
	{
		"pattern": "^\\d{3}-\\d{2}-\\d{4}$",
		"name": "U.S. Social Security numbers"
	},
	{
		"pattern": "^\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}$",
		"name": "IPV4 addresses"
	},
	{
		"pattern": "^(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}$",
		"name": "Master Card Number"
	},
	{
		"pattern": "^((\\d{5}-\\d{4})|(\\d{5})|([A-Z]\\d[A-Z]\\s\\d[A-Z]\\d))$",
		"name": "U.S. Zip Number"
	},
]`;
var ChannelFilterOption;
(function (ChannelFilterOption) {
    ChannelFilterOption["IGNORE_CHANNELS"] = "IGNORE_CHANNELS";
    ChannelFilterOption["TARGET_CHANNELS"] = "TARGET_CHANNELS";
})(ChannelFilterOption = exports.ChannelFilterOption || (exports.ChannelFilterOption = {}));
exports.settings = [
    {
        id: AppSetting.DLPRules,
        public: true,
        type: settings_1.SettingType.CODE,
        packageValue: rulesInitialValue,
        value: rulesInitialValue,
        i18nLabel: 'DLP_rules',
        i18nDescription: 'DLP_rules_description',
        required: true,
    },
    {
        id: AppSetting.DLPModeratorChannel,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'DLP_moderator_channel',
        i18nDescription: 'DLP_moderator_channel_description',
        required: true,
    },
    {
        id: AppSetting.DLPContentControlType,
        public: true,
        type: settings_1.SettingType.SELECT,
        packageValue: ChannelFilterOption.IGNORE_CHANNELS,
        value: ChannelFilterOption.IGNORE_CHANNELS,
        values: [
            {
                key: ChannelFilterOption.IGNORE_CHANNELS,
                i18nLabel: 'Ignore Channels - Do not monitor any message in these channels',
            },
            {
                key: ChannelFilterOption.TARGET_CHANNELS,
                i18nLabel: 'Target Channels - Monitor messages only within these channels',
            },
        ],
        i18nLabel: 'DLP_content_control_type',
        required: true,
    },
    {
        id: AppSetting.DLPChannels,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'DLP_channels',
        i18nDescription: 'DLP_channels_description',
        required: true,
    },
    {
        id: AppSetting.DLPCensorOnlySensitiveInfo,
        public: true,
        type: settings_1.SettingType.BOOLEAN,
        packageValue: true,
        value: true,
        i18nLabel: 'DLP_Censor_only_sensitive_info',
        i18nDescription: 'DLP_Censor_only_sensitive_info_description',
        required: true,
    },
    {
        id: AppSetting.DLPCustomBlockedMessageTitle,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'DLP_blocked_message_title',
        i18nDescription: 'DLP_blocked_message_title_description',
        required: false,
    },
    {
        id: AppSetting.DLPCustomPendingApprovalMessage,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'DLP_custom_pending_approval_message',
        i18nDescription: 'DLP_custom_pending_approval_message_description',
        required: false,
    },
    {
        id: AppSetting.DLPCustomRejectedMessage,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'DLP_custom_rejected_message',
        i18nDescription: 'DLP_custom_rejected_message_description',
        required: false,
    },
];
