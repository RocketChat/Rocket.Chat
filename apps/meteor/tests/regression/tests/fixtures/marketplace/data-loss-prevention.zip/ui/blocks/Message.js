"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.moreInfoMessageBlock = exports.blockedMessageTitleBlock = exports.moderatorMessageBlock = void 0;
const uikit_1 = require("@rocket.chat/apps-engine/definition/uikit");
const Settings_1 = require("../../config/Settings");
const Blocks_1 = require("../../enum/Blocks");
const Settings_2 = require("../../lib/Settings");
const moderatorMessageBlock = async (modify, dlpMessage) => {
    const blocks = modify.getCreator().getBlockBuilder();
    const { originalMessage, originalMessageId, messageSender, matchedRules, moderatorRoomTextMsg } = dlpMessage;
    blocks.addSectionBlock({
        text: blocks.newMarkdownTextObject(`**Rule(s): **${matchedRules === null || matchedRules === void 0 ? void 0 : matchedRules.join(', ')}\n\n**@${messageSender}** is trying to share sensitive content ${moderatorRoomTextMsg}\n\n**Original Message:**\n__${originalMessage}__`),
    });
    blocks.addActionsBlock({
        elements: [
            {
                type: uikit_1.BlockElementType.BUTTON,
                text: {
                    type: uikit_1.TextObjectType.PLAINTEXT,
                    text: Blocks_1.BlocksEnum.APPROVE,
                },
                actionId: Blocks_1.ACTION_ID.APPROVE,
                style: uikit_1.ButtonStyle.PRIMARY,
                value: originalMessageId,
            },
            {
                type: uikit_1.BlockElementType.BUTTON,
                text: {
                    type: uikit_1.TextObjectType.PLAINTEXT,
                    text: Blocks_1.BlocksEnum.REJECT,
                },
                actionId: Blocks_1.ACTION_ID.REJECT,
                style: uikit_1.ButtonStyle.DANGER,
                value: originalMessageId,
            },
        ],
    });
    return blocks;
};
exports.moderatorMessageBlock = moderatorMessageBlock;
const blockedMessageTitleBlock = async (appId, read) => {
    const blockedMessageTitle = await Settings_2.getAppSettingValue(read, Settings_1.AppSetting.DLPCustomBlockedMessageTitle);
    return {
        type: uikit_1.BlockType.CONTEXT,
        appId,
        elements: [
            {
                type: uikit_1.TextObjectType.MARKDOWN,
                text: blockedMessageTitle && blockedMessageTitle.length > 0 ?
                    blockedMessageTitle :
                    Settings_1.DefaultMessage.DEFAULT_BLOCKED_MESSAGE_TITLE,
            },
        ],
    };
};
exports.blockedMessageTitleBlock = blockedMessageTitleBlock;
const moreInfoMessageBlock = (appId, messageId) => {
    return {
        type: uikit_1.BlockType.CONDITIONAL,
        appId,
        when: {
            engine: [uikit_1.ConditionalBlockFiltersEngine.ROCKETCHAT],
        },
        render: [
            {
                type: uikit_1.BlockType.ACTIONS,
                appId,
                blockId: 'more-info',
                elements: [
                    {
                        type: uikit_1.BlockElementType.BUTTON,
                        text: {
                            type: uikit_1.TextObjectType.PLAINTEXT,
                            text: Blocks_1.BlocksEnum.MORE_INFO,
                        },
                        actionId: Blocks_1.ACTION_ID.MORE_INFO,
                        style: uikit_1.ButtonStyle.PRIMARY,
                        value: messageId,
                    },
                ],
            },
        ],
    };
};
exports.moreInfoMessageBlock = moreInfoMessageBlock;
