"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostMessageDeletedHandler = void 0;
const uikit_1 = require("@rocket.chat/apps-engine/definition/uikit");
class PostMessageDeletedHandler {
    constructor(app, message, read, http, persis, modify) {
        this.app = app;
        this.message = message;
        this.read = read;
        this.http = http;
        this.persis = persis;
        this.modify = modify;
    }
    async run() {
        const { customFields: { moderatorRoomMessageId } = {}, sender: { username } } = this.message;
        if (!moderatorRoomMessageId || moderatorRoomMessageId.trim().length === 0) {
            return;
        }
        const msgEditor = await this.modify.getUpdater().message(moderatorRoomMessageId, this.app.appUser);
        const blocksBuilder = this.modify.getCreator().getBlockBuilder();
        if (this.isPendingModeration(msgEditor.getBlocks())) {
            const originalBlocks = msgEditor.getBlocks().filter(({ type }) => type !== uikit_1.BlockType.ACTIONS);
            const messageDeletedBlock = blocksBuilder.addContextBlock({
                elements: [
                    blocksBuilder.newPlainTextObject(`@${username} has deleted this message`),
                ],
            }).getBlocks();
            msgEditor.setBlocks([...originalBlocks, ...messageDeletedBlock]);
            msgEditor.setEditor(this.app.appUser);
            await this.modify.getUpdater().finish(msgEditor);
        }
    }
    isPendingModeration(blocks) {
        return blocks.filter(({ type }) => type === uikit_1.BlockType.ACTIONS).length > 0;
    }
}
exports.PostMessageDeletedHandler = PostMessageDeletedHandler;
