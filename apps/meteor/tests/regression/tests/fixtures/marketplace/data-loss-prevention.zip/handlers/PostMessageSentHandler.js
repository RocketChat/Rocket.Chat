"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostMessageSentHandler = void 0;
const Settings_1 = require("../config/Settings");
const Message_1 = require("../lib/Message");
const Settings_2 = require("../lib/Settings");
const Message_2 = require("../ui/blocks/Message");
class PostMessageSentHandler {
    constructor(app, message, read, http, persis, modify) {
        this.app = app;
        this.message = message;
        this.read = read;
        this.http = http;
        this.persis = persis;
        this.modify = modify;
    }
    async run() {
        const { customFields: { dlpMessage } = {} } = this.message;
        if (!dlpMessage) {
            return;
        }
        const moderatorRoomName = await Settings_2.getAppSettingValue(this.read, Settings_1.AppSetting.DLPModeratorChannel);
        if (!moderatorRoomName || moderatorRoomName.trim().length === 0) {
            return;
        }
        const moderatorRoom = await this.read.getRoomReader().getByName(moderatorRoomName);
        if (!moderatorRoom) {
            return;
        }
        const { originalMessageId } = dlpMessage;
        const blocks = await Message_2.moderatorMessageBlock(this.modify, dlpMessage);
        const moderatorRoomMessageId = await Message_1.sendRoomMessage(this.app, this.modify, moderatorRoom, undefined, undefined, blocks);
        await Message_1.addCustomFieldToMessage(this.modify, originalMessageId, this.app.appUser, 'moderatorRoomMessageId', moderatorRoomMessageId);
    }
}
exports.PostMessageSentHandler = PostMessageSentHandler;
