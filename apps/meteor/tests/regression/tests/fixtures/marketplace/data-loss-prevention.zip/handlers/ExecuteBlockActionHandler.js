"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExecuteBlockActionHandler = void 0;
const uikit_1 = require("@rocket.chat/apps-engine/definition/uikit");
const App_1 = require("../enum/App");
const Blocks_1 = require("../enum/Blocks");
const Message_1 = require("../lib/Message");
const MoreInfoModal_1 = require("../ui/modals/MoreInfoModal");
class ExecuteBlockActionHandler {
    constructor(app, read, http, modify, persistence) {
        this.app = app;
        this.read = read;
        this.http = http;
        this.modify = modify;
        this.persistence = persistence;
    }
    async run(context) {
        const data = context.getInteractionData();
        const { actionId, value = '', message, user } = data;
        if (!value || !message) {
            throw new Error(App_1.ErrorEnum.RoomOrValueUndefined);
        }
        switch (actionId) {
            case Blocks_1.ACTION_ID.APPROVE: {
                await this.approveMessage(value, message, user);
                break;
            }
            case Blocks_1.ACTION_ID.REJECT: {
                await this.rejectMessage(value, message, user);
                break;
            }
            case Blocks_1.ACTION_ID.MORE_INFO: {
                return await this.processMoreInfoAction(context, value, message);
            }
        }
        return {
            success: true,
        };
    }
    async processMoreInfoAction(context, originalMessageId, moderatorChannelMessage) {
        if (!originalMessageId || !moderatorChannelMessage || !moderatorChannelMessage.id) {
            return this.app.getLogger().error(`${App_1.ErrorEnum.ErrorRejectingMessage}OriginalMessageId or moderatorChannelMessage undefined`);
        }
        const originalMessage = await this.read.getMessageReader().getById(originalMessageId);
        if (!originalMessageId) {
            return this.app.getLogger().error(`${App_1.ErrorEnum.ErrorRejectingMessage}OriginalMessage undefined`);
        }
        const { customFields: { dlpMessage, dlpMessageRejected } = {} } = originalMessage;
        if (!dlpMessage) {
            return this.app.getLogger().error(`${App_1.ErrorEnum.ErrorRejectingMessage}dlpMessage customField undefined`);
        }
        const { matchedRules = [] } = dlpMessage;
        const status = dlpMessageRejected ? App_1.ModerationStatus.REJECTED : App_1.ModerationStatus.PENDING_APPROVAL;
        const modal = await MoreInfoModal_1.MoreInfoModal({ matchedRules, modify: this.modify, read: this.read, status });
        return this.modify.getUiController().openModalView(modal, { triggerId: context.getInteractionData().triggerId }, context.getInteractionData().user);
    }
    async approveMessage(originalMessageId, moderatorChannelMessage, approvedBy) {
        if (!originalMessageId || !moderatorChannelMessage || !moderatorChannelMessage.id) {
            return this.app.getLogger().error(`${App_1.ErrorEnum.ErrorApprovingMessage} OriginalMessageId or moderatorChannelMessage undefined`);
        }
        const originalMessage = await this.read.getMessageReader().getById(originalMessageId);
        if (!originalMessage) {
            return this.app.getLogger().error(`${App_1.ErrorEnum.ErrorApprovingMessage} OriginalMessage undefined`);
        }
        const { customFields: { dlpMessage } = {} } = originalMessage;
        if (!dlpMessage) {
            return this.app.getLogger().error(`${App_1.ErrorEnum.ErrorApprovingMessage} dlpMessage customField undefined`);
        }
        const { originalMessage: originalMessageText } = dlpMessage;
        const messageSender = this.app.appUser;
        await this.unBlockMessage(originalMessageId, originalMessageText, messageSender);
        await this.postModeration(messageSender, moderatorChannelMessage.id, approvedBy, Blocks_1.ActionEnum.APPROVED);
    }
    async rejectMessage(originalMessageId, moderatorChannelMessage, approvedBy) {
        if (!originalMessageId || !moderatorChannelMessage || !moderatorChannelMessage.id) {
            return this.app.getLogger().error(`${App_1.ErrorEnum.ErrorRejectingMessage}OriginalMessageId or moderatorChannelMessage undefined`);
        }
        const originalMessage = await this.read.getMessageReader().getById(originalMessageId);
        if (!originalMessageId) {
            return this.app.getLogger().error(`${App_1.ErrorEnum.ErrorRejectingMessage}OriginalMessage undefined`);
        }
        const { customFields: { dlpMessage } = {} } = originalMessage;
        if (!dlpMessage) {
            return this.app.getLogger().error(`${App_1.ErrorEnum.ErrorRejectingMessage}dlpMessage customField undefined`);
        }
        const messageSender = this.app.appUser;
        await this.notifyMessageBlockedPermanently(originalMessageId, messageSender);
        await this.postModeration(messageSender, moderatorChannelMessage.id, approvedBy, Blocks_1.ActionEnum.REJECTED);
    }
    async notifyMessageBlockedPermanently(messageId, messageSender) {
        const msg = await this.modify.getUpdater().message(messageId, messageSender);
        msg.setEditor(messageSender);
        await this.modify.getUpdater().finish(msg);
        await Message_1.addCustomFieldToMessage(this.modify, messageId, messageSender, 'dlpMessageRejected', true);
    }
    async unBlockMessage(messageId, messageText, messageSender) {
        const msg = await this.modify.getUpdater().message(messageId, messageSender);
        msg.setAttachments([]);
        msg.setBlocks([]);
        msg.setText(messageText);
        msg.setEditor(messageSender);
        await this.modify.getUpdater().finish(msg);
    }
    async postModeration(messageSender, moderatorChannelMessageId, approvedBy, action) {
        const msg = await this.modify.getUpdater().message(moderatorChannelMessageId, messageSender);
        const blocksBuilder = this.modify.getCreator().getBlockBuilder();
        const originalBlocks = msg.getBlocks().filter(({ type }) => type !== uikit_1.BlockType.ACTIONS);
        const approvalByBlock = blocksBuilder.addContextBlock({
            elements: [
                blocksBuilder.newPlainTextObject(`${action} by @${approvedBy.username}`),
            ],
        }).getBlocks();
        msg.setBlocks([...originalBlocks, ...approvalByBlock]);
        msg.setEditor(messageSender);
        await this.modify.getUpdater().finish(msg);
    }
}
exports.ExecuteBlockActionHandler = ExecuteBlockActionHandler;
