"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MoreInfoModal = void 0;
const blocks_1 = require("@rocket.chat/apps-engine/definition/uikit/blocks");
const Settings_1 = require("../../config/Settings");
const App_1 = require("../../enum/App");
const Blocks_1 = require("../../enum/Blocks");
const Settings_2 = require("../../lib/Settings");
async function MoreInfoModal({ modify, read, matchedRules, status }) {
    const viewId = 'moreInfoModal';
    const block = modify.getCreator().getBlockBuilder();
    const pendingMessage = await Settings_2.getAppSettingValue(read, Settings_1.AppSetting.DLPCustomPendingApprovalMessage);
    const rejectedMessage = await Settings_2.getAppSettingValue(read, Settings_1.AppSetting.DLPCustomRejectedMessage);
    if (matchedRules && matchedRules.length > 0) {
        block.addSectionBlock({
            text: block.newMarkdownTextObject(Settings_1.DefaultMessage.MORE_INFO_MODAL_BLOCKED_TYPES),
        });
        matchedRules.forEach((rule) => {
            block.addSectionBlock({
                text: block.newMarkdownTextObject(`>- ${rule}`),
            });
        });
        block.addDividerBlock();
    }
    let moderationStatusMessage = '';
    switch (status) {
        case App_1.ModerationStatus.PENDING_APPROVAL: {
            moderationStatusMessage = pendingMessage && pendingMessage.trim().length > 0 ? pendingMessage : Settings_1.DefaultMessage.DEFAULT_PENDING_APPROVAL_MESSAGE;
            break;
        }
        case App_1.ModerationStatus.REJECTED: {
            moderationStatusMessage = rejectedMessage && rejectedMessage.trim().length > 0 ? rejectedMessage : Settings_1.DefaultMessage.DEFAULT_REJECTED_MESSAGE;
        }
    }
    if (moderationStatusMessage && moderationStatusMessage.trim().length > 0) {
        block.addSectionBlock({
            text: block.newMarkdownTextObject(`**Status:** ${status}`),
        });
        block.addContextBlock({
            elements: [
                block.newMarkdownTextObject(moderationStatusMessage),
            ],
        });
    }
    return {
        id: viewId,
        title: {
            type: blocks_1.TextObjectType.PLAINTEXT,
            text: Blocks_1.AlertsEnum.moreInfoModalTitle,
        },
        close: block.newButtonElement({
            text: {
                type: blocks_1.TextObjectType.PLAINTEXT,
                text: Blocks_1.BlocksEnum.CLOSE,
            },
        }),
        blocks: block.getBlocks(),
    };
}
exports.MoreInfoModal = MoreInfoModal;
