"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DLPApp = void 0;
const App_1 = require("@rocket.chat/apps-engine/definition/App");
const Settings_1 = require("./config/Settings");
const App_2 = require("./enum/App");
const ExecuteBlockActionHandler_1 = require("./handlers/ExecuteBlockActionHandler");
const PostMessageDeletedHandler_1 = require("./handlers/PostMessageDeletedHandler");
const PostMessageSentHandler_1 = require("./handlers/PostMessageSentHandler");
const PreMessageSentModify_1 = require("./handlers/PreMessageSentModify");
const Rules_1 = require("./lib/Rules");
const Settings_2 = require("./lib/Settings");
const DialogModal_1 = require("./ui/modals/DialogModal");
class DLPApp extends App_1.App {
    constructor(info, logger, accessors) {
        super(info, logger, accessors);
    }
    async executePreMessageUpdatedPrevent(message, read, http, persistence) {
        const { customFields: { dlpMessage } = {}, editor: { username: editorUsername } = {} } = message;
        return dlpMessage && editorUsername !== this.appUser.username;
    }
    async onEnable() {
        const read = this.getAccessors().reader;
        this.appUser = await read.getUserReader().getAppUser(this.getID());
        if (!this.appUser) {
            this.getLogger().error('Error occurred while setting app user');
            return false;
        }
        const rulesString = await Settings_2.getAppSettingValue(read, Settings_1.AppSetting.DLPRules);
        if (!rulesString || rulesString.trim().length === 0) {
            return true;
        }
        this.rules = await Rules_1.getRulesFromSettings(rulesString, this.getLogger());
        return true;
    }
    async executePreMessageSentModify(message, builder, read, http, persistence) {
        try {
            const handler = new PreMessageSentModify_1.PreMessageSentModifyHandler(this, message, builder, read, http, persistence);
            return await handler.run();
        }
        catch (err) {
            this.getLogger().log(`${err.message}`);
        }
        return message;
    }
    async executePostMessageSent(message, read, http, persistence, modify) {
        try {
            const handler = new PostMessageSentHandler_1.PostMessageSentHandler(this, message, read, http, persistence, modify);
            return await handler.run();
        }
        catch (err) {
            return this.getLogger().log(`${err.message}`);
        }
    }
    async onSettingUpdated(setting, configurationModify, read, http) {
        if (setting.id === Settings_1.AppSetting.DLPRules && setting.value && setting.value.length > 0) {
            this.rules = await Rules_1.getRulesFromSettings(setting.value, this.getLogger());
        }
    }
    async executeBlockActionHandler(context, read, http, persistence, modify) {
        try {
            const handler = new ExecuteBlockActionHandler_1.ExecuteBlockActionHandler(this, read, http, modify, persistence);
            return await handler.run(context);
        }
        catch (err) {
            this.getLogger().log(`${err.message}`);
            const alert = await DialogModal_1.dialogModal({ text: App_2.ErrorEnum.ErrorOperationFailedMessage, modify });
            return context.getInteractionResponder().openModalViewResponse(alert);
        }
    }
    async executePostMessageDeleted(message, read, http, persistence, modify) {
        try {
            const handler = new PostMessageDeletedHandler_1.PostMessageDeletedHandler(this, message, read, http, persistence, modify);
            return await handler.run();
        }
        catch (err) {
            return this.getLogger().log(err);
        }
    }
    async extendConfiguration(configuration) {
        await Promise.all(Settings_1.settings.map((setting) => configuration.settings.provideSetting(setting)));
    }
}
exports.DLPApp = DLPApp;
