"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dialogModal = void 0;
const blocks_1 = require("@rocket.chat/apps-engine/definition/uikit/blocks");
const Blocks_1 = require("../../enum/Blocks");
async function dialogModal({ title, text, modify }) {
    const viewId = 'dialogModal';
    const block = modify.getCreator().getBlockBuilder();
    block.addSectionBlock({
        text: block.newMarkdownTextObject(text),
    });
    return {
        id: viewId,
        title: {
            type: blocks_1.TextObjectType.PLAINTEXT,
            text: title || Blocks_1.AlertsEnum.defaultTitle,
        },
        close: block.newButtonElement({
            text: {
                type: blocks_1.TextObjectType.PLAINTEXT,
                text: Blocks_1.BlocksEnum.DISMISS,
            },
        }),
        blocks: block.getBlocks(),
    };
}
exports.dialogModal = dialogModal;
