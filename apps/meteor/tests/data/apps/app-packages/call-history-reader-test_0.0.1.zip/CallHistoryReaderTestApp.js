'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
exports.CallHistoryReaderTestApp = void 0;

const { App } = require('@rocket.chat/apps-engine/definition/App');
const { ApiEndpoint, ApiSecurity, ApiVisibility } = require('@rocket.chat/apps-engine/definition/api');

class ReadByIdEndpoint extends ApiEndpoint {
	constructor() {
		super(...arguments);
		this.path = 'read-by-id';
	}

	async get(request, _endpoint, read) {
		const { historyId } = request.query;
		if (!historyId) {
			return { status: 400, content: { error: 'historyId query parameter is required' } };
		}

		const entry = await read.getCallHistoryReader().getById(historyId);

		return { status: 200, content: { entry: entry || null } };
	}
}

class ReadByCallIdEndpoint extends ApiEndpoint {
	constructor() {
		super(...arguments);
		this.path = 'read-by-call-id';
	}

	async get(request, _endpoint, read) {
		const { callId } = request.query;
		if (!callId) {
			return { status: 400, content: { error: 'callId query parameter is required' } };
		}

		const entries = await read.getCallHistoryReader().getByCallId(callId);

		return { status: 200, content: { entries } };
	}
}

class FindEndpoint extends ApiEndpoint {
	constructor() {
		super(...arguments);
		this.path = 'find';
	}

	async get(request, _endpoint, read) {
		const { uid, direction, states, count, offset, from, to } = request.query;

		const query = {};
		if (uid) {
			query.uid = uid;
		}
		if (direction) {
			query.direction = direction;
		}
		if (states) {
			query.states = states.split(',');
		}
		if (count) {
			query.count = Number(count);
		}
		if (offset) {
			query.offset = Number(offset);
		}
		if (from) {
			query.from = new Date(from);
		}
		if (to) {
			query.to = new Date(to);
		}

		const page = await read.getCallHistoryReader().find(query);

		return { status: 200, content: page };
	}
}

class CallHistoryReaderTestApp extends App {
	constructor(info, logger, accessors) {
		super(info, logger, accessors);
	}

	async extendConfiguration(configuration) {
		await configuration.api.provideApi({
			visibility: ApiVisibility.PUBLIC,
			security: ApiSecurity.UNSECURE,
			endpoints: [new ReadByIdEndpoint(this), new ReadByCallIdEndpoint(this), new FindEndpoint(this)],
		});
	}
}

exports.CallHistoryReaderTestApp = CallHistoryReaderTestApp;
