"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppUpdateTestApp = void 0;
const App_1 = require("@rocket.chat/apps-engine/definition/App");
class AppUpdateTestApp extends App_1.App {
    constructor(info, logger, accessors) {
        super(info, logger, accessors);
    }
    // Intentionally throws so the update lands in ERROR_DISABLED, exercising
    // the "update failed -> bot user status must remain unchanged" path.
    async onEnable() {
        throw new Error("Intentional failure for E2E update-failure test");
    }
}
exports.AppUpdateTestApp = AppUpdateTestApp;
