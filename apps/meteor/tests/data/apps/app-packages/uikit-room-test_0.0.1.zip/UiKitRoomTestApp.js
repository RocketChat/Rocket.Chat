"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UiKitRoomTestApp = void 0;
const App_1 = require("@rocket.chat/apps-engine/definition/App");
const metadata_1 = require("@rocket.chat/apps-engine/definition/metadata");
const uikit_1 = require("@rocket.chat/apps-engine/definition/uikit");
class UiKitRoomTestApp extends App_1.App {
    constructor(info, logger, accessors) {
        super(info, logger, accessors);
    }
    async [metadata_1.AppMethod.UIKIT_BLOCK_ACTION](context, _read, _http, _persistence, _modify) {
        const data = context.getInteractionData();
        this.getLogger().debug('block_action_room', data.room ? data.room.id : 'no-room');
        this.getLogger().debug('block_action_user', data.user ? data.user.username : 'no-user');
        this.getLogger().debug('block_action_triggerId', data.triggerId || 'no-triggerId');
        this.getLogger().debug('block_action_actionId', data.actionId || 'no-actionId');
        this.getLogger().debug('block_action_container', data.container ? data.container.type : 'no-container');
        return context.getInteractionResponder().successResponse();
    }
    async [metadata_1.AppMethod.UIKIT_VIEW_SUBMIT](context, _read, _http, _persistence, _modify) {
        const data = context.getInteractionData();
        this.getLogger().debug('view_submit_room', data.room ? data.room.id : 'no-room');
        this.getLogger().debug('view_submit_user', data.user ? data.user.username : 'no-user');
        this.getLogger().debug('view_submit_triggerId', data.triggerId || 'no-triggerId');
        return context.getInteractionResponder().successResponse();
    }
    async [metadata_1.AppMethod.UIKIT_VIEW_CLOSE](context, _read, _http, _persistence, _modify) {
        const data = context.getInteractionData();
        this.getLogger().debug('view_closed_room', data.room ? data.room.id : 'no-room');
        this.getLogger().debug('view_closed_user', data.user ? data.user.username : 'no-user');
        this.getLogger().debug('view_closed_triggerId', data.triggerId || 'no-triggerId');
        return context.getInteractionResponder().successResponse();
    }
    async extendConfiguration(configuration, _environmentRead) {
        await configuration.slashCommands.provideSlashCommand({
            command: 'open-uikit-room-test-modal',
            i18nDescription: '',
            i18nParamsExample: '',
            providesPreview: false,
            executor: async (context, _read, modify, _http, _persis) => {
                const [action] = context.getArguments();
                const triggerId = context.getTriggerId();
                if (!triggerId) {
                    this.getLogger().error('No triggerId provided to slash command');
                    return;
                }
                if (action === 'modal') {
                    await modify.getUiController().openSurfaceView({
                        title: {
                            type: 'plain_text',
                            text: 'UIKit Room Test Modal',
                        },
                        type: uikit_1.UIKitSurfaceType.MODAL,
                        blocks: [
                            {
                                type: 'section',
                                text: {
                                    type: 'plain_text',
                                    text: 'This modal tests room context in UIKit interactions.',
                                },
                            },
                            {
                                type: 'actions',
                                elements: [
                                    {
                                        type: 'button',
                                        actionId: 'modal-button',
                                        text: { type: 'plain_text', text: 'Click!' },
                                    },
                                ],
                            },
                        ],
                        submit: {
                            type: 'button',
                            actionId: 'modal-submit',
                            text: {
                                type: 'plain_text',
                                text: 'Submit',
                            },
                        },
                    }, { triggerId }, context.getSender());
                }
                if (action === 'ctx') {
                    await modify.getUiController().openSurfaceView({
                        title: {
                            type: 'plain_text',
                            text: 'UIKit Room Test Contextual Bar',
                        },
                        type: uikit_1.UIKitSurfaceType.CONTEXTUAL_BAR,
                        blocks: [
                            {
                                type: 'section',
                                text: {
                                    type: 'plain_text',
                                    text: 'This contextual bar tests room context.',
                                },
                            },
                            {
                                type: 'actions',
                                elements: [
                                    {
                                        type: 'button',
                                        actionId: 'ctx-button',
                                        text: { type: 'plain_text', text: 'Click!' },
                                    },
                                ],
                            },
                        ],
                        submit: {
                            type: 'button',
                            actionId: 'ctxbar-submit',
                            text: {
                                type: 'plain_text',
                                text: 'Submit',
                            },
                        },
                    }, { triggerId }, context.getSender());
                }
                if (action === 'message') {
                    const msg = modify
                        .getCreator()
                        .startMessage()
                        .setRoom(context.getRoom())
                        .setBlocks([
                        {
                            type: 'section',
                            text: {
                                type: 'plain_text',
                                text: 'This message tests room context.',
                            },
                        },
                        {
                            type: 'actions',
                            elements: [
                                {
                                    type: 'button',
                                    actionId: 'msg-button',
                                    text: { type: 'plain_text', text: 'Click!' },
                                },
                            ],
                        },
                    ]);
                    await modify.getCreator().finish(msg);
                }
            },
        });
    }
}
exports.UiKitRoomTestApp = UiKitRoomTestApp;
