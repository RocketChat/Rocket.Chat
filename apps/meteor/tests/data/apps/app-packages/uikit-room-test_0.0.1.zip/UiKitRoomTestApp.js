"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UiKitRoomTestApp = void 0;
const App_1 = require("@rocket.chat/apps-engine/definition/App");
class OpenModalCommand {
    constructor(app) {
        this.app = app;
        this.command = 'open-uikit-room-test-modal';
        this.i18nParamsExample = '';
        this.i18nDescription = '';
        this.providesPreview = false;
    }
    async executor(context, _read, modify) {
        const triggerId = context.getTriggerId();
        const room = context.getRoom();
        const sender = context.getSender();
        if (!triggerId) {
            this.app.getLogger().error('No triggerId provided to slash command');
            return;
        }
        this.app.getLogger().debug('open_modal_slash_command', room.id);
        await modify.getUiController().openModalView({
            title: {
                type: 'plain_text',
                text: 'UIKit Room Test Modal',
            },
            blocks: [
                {
                    type: 'section',
                    blockId: 'test_block',
                    text: {
                        type: 'mrkdwn',
                        text: 'This modal is used to test room context in UIKit interactions.',
                    },
                },
            ],
        }, { triggerId }, sender);
    }
}
class UiKitRoomTestApp extends App_1.App {
    constructor(info, logger, accessors) {
        super(info, logger, accessors);
    }
    async extendConfiguration(configuration) {
        await configuration.slashCommands.provideSlashCommand(new OpenModalCommand(this));
    }
    async executeBlockActionHandler(context, _read, _http, _persistence, _modify) {
        const data = context.getInteractionData();
        this.getLogger().debug('block_action_room', data.room ? data.room.id : 'no-room');
        return context.getInteractionResponder().successResponse();
    }
    async executeViewSubmitHandler(context, _read, _http, _persistence, _modify) {
        const data = context.getInteractionData();
        this.getLogger().debug('view_submit_room', data.room ? data.room.id : 'no-room');
        return context.getInteractionResponder().successResponse();
    }
    async executeViewClosedHandler(context, _read, _http, _persistence, _modify) {
        const data = context.getInteractionData();
        this.getLogger().debug('view_closed_room', data.room ? data.room.id : 'no-room');
        return context.getInteractionResponder().successResponse();
    }
}
exports.UiKitRoomTestApp = UiKitRoomTestApp;
