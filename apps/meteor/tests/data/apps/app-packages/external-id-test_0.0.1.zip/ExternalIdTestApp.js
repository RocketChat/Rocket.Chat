"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExternalIdTestApp = void 0;
const App_1 = require("@rocket.chat/apps-engine/definition/App");
const api_1 = require("@rocket.chat/apps-engine/definition/api");
const ResolveVisitorEndpoint_1 = require("./ResolveVisitorEndpoint");
const UpdateExternalIdEndpoint_1 = require("./UpdateExternalIdEndpoint");
class ExternalIdTestApp extends App_1.App {
    constructor(info, logger, accessors) {
        super(info, logger, accessors);
    }
    async extendConfiguration(configuration) {
        await configuration.api.provideApi({
            visibility: api_1.ApiVisibility.PUBLIC,
            security: api_1.ApiSecurity.UNSECURE,
            endpoints: [new ResolveVisitorEndpoint_1.ResolveVisitorEndpoint(this), new UpdateExternalIdEndpoint_1.UpdateExternalIdEndpoint(this)],
        });
    }
}
exports.ExternalIdTestApp = ExternalIdTestApp;
