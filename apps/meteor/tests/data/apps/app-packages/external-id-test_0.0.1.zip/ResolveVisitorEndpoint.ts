import {
	HttpStatusCode,
	IHttp,
	IModify,
	IPersistence,
	IRead,
} from '@rocket.chat/apps-engine/definition/accessors';
import { ApiEndpoint, IApiEndpointInfo, IApiRequest, IApiResponse } from '@rocket.chat/apps-engine/definition/api';

export class ResolveVisitorEndpoint extends ApiEndpoint {
	public override path = 'resolve-visitor';

	public async post(
		request: IApiRequest,
		_endpoint: IApiEndpointInfo,
		_read: IRead,
		modify: IModify,
		_http: IHttp,
		_persistence: IPersistence,
	): Promise<IApiResponse> {
		const { externalId, phone, email } = request.content;

		let contactData: { phone: string } | { email: string } | undefined;

		if (phone) {
			contactData = { phone };
		} else if (email) {
			contactData = { email };
		}

		const visitor = await modify.getCreator().getLivechatCreator().resolveVisitor(externalId, contactData);

		return {
			status: HttpStatusCode.OK,
			content: { visitor: visitor || null },
		};
	}
}
