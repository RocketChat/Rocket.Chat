import {
	HttpStatusCode,
	IHttp,
	IModify,
	IPersistence,
	IRead,
} from '@rocket.chat/apps-engine/definition/accessors';
import { ApiEndpoint, IApiEndpointInfo, IApiRequest, IApiResponse } from '@rocket.chat/apps-engine/definition/api';

export class UpdateExternalIdEndpoint extends ApiEndpoint {
	public override path = 'update-external-id';

	public async post(
		request: IApiRequest,
		_endpoint: IApiEndpointInfo,
		_read: IRead,
		modify: IModify,
		_http: IHttp,
		_persistence: IPersistence,
	): Promise<IApiResponse> {
		const { visitorId, externalId } = request.content;

		if (!visitorId || !externalId) {
			return {
				status: HttpStatusCode.BAD_REQUEST,
				content: { error: 'visitorId and externalId are required' },
			};
		}

		const visitor = await modify.getUpdater().getLivechatUpdater().updateVisitorExternalId(visitorId, externalId);

		return {
			status: HttpStatusCode.OK,
			content: { visitor: visitor || null },
		};
	}
}
