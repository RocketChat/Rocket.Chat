"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateExternalIdEndpoint = void 0;
const accessors_1 = require("@rocket.chat/apps-engine/definition/accessors");
const api_1 = require("@rocket.chat/apps-engine/definition/api");
class UpdateExternalIdEndpoint extends api_1.ApiEndpoint {
    constructor() {
        super(...arguments);
        this.path = 'update-external-id';
    }
    async post(request, _endpoint, _read, modify, _http, _persistence) {
        const { visitorId, externalId } = request.content;
        if (!visitorId || !externalId) {
            return {
                status: accessors_1.HttpStatusCode.BAD_REQUEST,
                content: { error: 'visitorId and externalId are required' },
            };
        }
        const visitor = await modify.getUpdater().getLivechatUpdater().updateVisitorExternalId(visitorId, externalId);
        return {
            status: accessors_1.HttpStatusCode.OK,
            content: { visitor: visitor || null },
        };
    }
}
exports.UpdateExternalIdEndpoint = UpdateExternalIdEndpoint;
