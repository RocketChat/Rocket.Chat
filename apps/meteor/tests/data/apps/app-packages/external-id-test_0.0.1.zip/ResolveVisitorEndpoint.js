"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResolveVisitorEndpoint = void 0;
const accessors_1 = require("@rocket.chat/apps-engine/definition/accessors");
const api_1 = require("@rocket.chat/apps-engine/definition/api");
class ResolveVisitorEndpoint extends api_1.ApiEndpoint {
    constructor() {
        super(...arguments);
        this.path = 'resolve-visitor';
    }
    async post(request, _endpoint, _read, modify, _http, _persistence) {
        const { externalId, phone, email } = request.content;
        let contactData;
        if (phone) {
            contactData = { phone };
        }
        else if (email) {
            contactData = { email };
        }
        const visitor = await modify.getCreator().getLivechatCreator().resolveVisitor(externalId, contactData);
        return {
            status: accessors_1.HttpStatusCode.OK,
            content: { visitor: visitor || null },
        };
    }
}
exports.ResolveVisitorEndpoint = ResolveVisitorEndpoint;
