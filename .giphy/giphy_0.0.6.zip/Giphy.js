"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const App_1 = require("@rocket.chat/apps-engine/definition/App");
const settings_1 = require("@rocket.chat/apps-engine/definition/settings");
const GiphyCommand_1 = require("./commands/GiphyCommand");
const GifGetter_1 = require("./helpers/GifGetter");
class Giphy extends App_1.App {
    constructor(info, logger) {
        super(info, logger);
        this.gifGetter = new GifGetter_1.GifGetter();
    }
    getGifGetter() {
        return this.gifGetter;
    }
    async extendConfiguration(configuration, environmentRead) {
        await configuration.settings.provideSetting({
            id: 'giphy_apikey',
            type: settings_1.SettingType.STRING,
            packageValue: '',
            required: true,
            public: false,
            i18nLabel: 'Customize_GIPHY_APIKey',
            i18nDescription: 'Customize_GIPHY_APIKey_Description',
        });
        await configuration.settings.provideSetting({
            id: 'giphy_lang_code',
            type: settings_1.SettingType.STRING,
            packageValue: 'en',
            required: true,
            public: false,
            i18nLabel: 'Customize_GIPHY_Language',
            i18nDescription: 'Customize_GIPHY_Language_Description',
        });
        await configuration.settings.provideSetting({
            id: 'giphy_rating',
            type: settings_1.SettingType.STRING,
            packageValue: 'G',
            required: true,
            public: false,
            i18nLabel: 'Customize_GIPHY_Rating',
            i18nDescription: 'Customize_GIPHY_Rating_Description',
        });
        await configuration.settings.provideSetting({
            id: 'giphy_show_title',
            type: settings_1.SettingType.BOOLEAN,
            packageValue: true,
            required: true,
            public: false,
            i18nLabel: 'Customize_GIPHY_Show_Title',
            i18nDescription: 'Customize_GIPHY_Show_Title_Description',
        });
        await configuration.slashCommands.provideSlashCommand(new GiphyCommand_1.GiphyCommand(this));
    }
}
exports.Giphy = Giphy;
