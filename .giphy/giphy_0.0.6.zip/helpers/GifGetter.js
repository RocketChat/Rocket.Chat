"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const accessors_1 = require("@rocket.chat/apps-engine/definition/accessors");
const GiphyResult_1 = require("../helpers/GiphyResult");
class GifGetter {
    constructor() {
        this.url = 'https://api.giphy.com/v1/gifs/';
        this.defaultKey = 'kICM0DRhpfvIcGLhtmCjqEigApnPMLXf';
    }
    async search(logger, http, phase, read) {
        let search = phase.trim();
        if (!search) {
            search = 'random';
        }
        const key = await read.getEnvironmentReader().getSettings().getValueById('giphy_apikey') || this.defaultKey;
        const langCode = await read.getEnvironmentReader().getSettings().getValueById('giphy_lang_code') || 'en';
        const rating = await read.getEnvironmentReader().getSettings().getValueById('giphy_rating') || 'g';
        const response = await http.get(`${this.url}search?api_key=${key}&q=${search}&limit=10&lang=${langCode}&rating=${rating}`);
        if (response.statusCode !== accessors_1.HttpStatusCode.OK || !response.data || !response.data.data) {
            logger.debug('Did not get a valid response', response);
            throw new Error('Unable to retrieve gifs.');
        }
        else if (!Array.isArray(response.data.data)) {
            logger.debug('The response data is not an Array:', response.data.data);
            throw new Error('Data is in a format we don\'t understand.');
        }
        return response.data.data.map((r) => new GiphyResult_1.GiphyResult(r));
    }
    async getOne(logger, http, gifId, read) {
        const key = await read.getEnvironmentReader().getSettings().getValueById('giphy_apikey') || this.defaultKey;
        const response = await http.get(`${this.url}${gifId}?api_key=${key}`);
        if (response.statusCode !== accessors_1.HttpStatusCode.OK || !response.data || !response.data.data) {
            logger.debug('Did not get a valid response', response);
            throw new Error('Unable to retrieve the gif.');
        }
        else if (typeof response.data.data !== 'object') {
            logger.debug('The response data is not an Object:', response.data.data);
            throw new Error('Data is in a format we don\'t understand.');
        }
        return new GiphyResult_1.GiphyResult(response.data.data);
    }
}
exports.GifGetter = GifGetter;
