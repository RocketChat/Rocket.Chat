"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const slashcommands_1 = require("@rocket.chat/apps-engine/definition/slashcommands");
class GiphyResult {
    constructor(data) {
        if (data) {
            this.id = data.id;
            this.title = data.title;
            this.previewUrl = data.images.fixed_height_small.url;
            this.originalUrl = data.images.original.url;
        }
    }
    toPreviewItem() {
        if (!this.id || !this.previewUrl) {
            throw new Error('Invalid result');
        }
        return {
            id: this.id,
            type: slashcommands_1.SlashCommandPreviewItemType.IMAGE,
            value: this.previewUrl,
        };
    }
}
exports.GiphyResult = GiphyResult;
