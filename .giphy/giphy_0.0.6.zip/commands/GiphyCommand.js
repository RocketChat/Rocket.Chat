"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class GiphyCommand {
    constructor(app) {
        this.app = app;
        this.command = 'giphy';
        this.i18nParamsExample = 'GIPHY_Search_Term';
        this.i18nDescription = 'GIPHY_Command_Description';
        this.providesPreview = true;
    }
    executor(context, read, modify, http, persis) {
        throw new Error('Method not implemented.');
    }
    async previewer(context, read, modify, http, persis) {
        let gifs;
        let items;
        try {
            gifs = await this.app.getGifGetter().search(this.app.getLogger(), http, context.getArguments().join(' '), read);
            items = gifs.map((gif) => gif.toPreviewItem());
        }
        catch (e) {
            this.app.getLogger().error('Failed on something:', e);
            return {
                i18nTitle: 'ERROR',
                items: new Array(),
            };
        }
        return {
            i18nTitle: 'Results for',
            items,
        };
    }
    async executePreviewItem(item, context, read, modify, http, persis) {
        const builder = modify.getCreator().startMessage().setSender(context.getSender()).setRoom(context.getRoom());
        const tid = context.getThreadId();
        if (tid) {
            builder.setThreadId(tid);
        }
        try {
            const gif = await this.app.getGifGetter().getOne(this.app.getLogger(), http, item.id, read);
            const showTitle = await read.getEnvironmentReader().getSettings().getValueById('giphy_show_title');
            const trigger = context.getArguments().join(' ').trim();
            builder.addAttachment({
                title: {
                    value: ((showTitle) ? gif.title.trim() : ''),
                },
                author: {
                    icon: 'https://raw.githubusercontent.com/wreiske/Rocket.Chat.App-Giphy/master/images/Giphy-256.png',
                    name: `/giphy ${trigger.trim()}`,
                    link: `https://giphy.com/search/${trigger.trim()}`,
                },
                imageUrl: gif.originalUrl
            });
            await modify.getCreator().finish(builder);
        }
        catch (e) {
            this.app.getLogger().error('Failed getting a gif', e);
            builder.setText('An error occurred when trying to send the gif :disappointed_relieved:');
            modify.getNotifier().notifyUser(context.getSender(), builder.getMessage());
        }
    }
}
exports.GiphyCommand = GiphyCommand;
