export enum TestingSettingsEnum {
    TESTING_PREFIX = 'testing-prefix',
    TESTING_A_BOOLEAN = 'testing-boolean',
    TESTING_A_COLOR = 'testing-color',
    TESTING_A_NUMBER = 'testing-number',
    TESTING_A_SELECT = 'testing-select',
    TESTING_A_MULTI_LINE_STRING = 'testing-multi-string',
    TESTING_A_CODE = 'testing-code',
}
