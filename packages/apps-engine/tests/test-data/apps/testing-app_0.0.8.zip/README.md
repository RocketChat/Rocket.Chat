# Testing App

What is this for?! Just to test out various pieces of the Rocket.Chat Apps framework via an App.

## Messages
* Prevent: yes, if it has the prefix and ` Prevent this`.
* Extend: yes, if it starts with the prefix. Adds an attachment.
* Modify: yes, if it starts with the prefix. Duplicates the message text.
* Post: yes, if it starts with the prefix. Sends a notification.
