"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecureFieldsTestApp = void 0;
const App_1 = require("@rocket.chat/apps-engine/definition/App");
class SecureFieldsTestApp extends App_1.App {
    constructor(info, logger, accessors) {
        super(info, logger, accessors);
    }
    async checkPreRoomCreatePrevent(room, read, http) {
        return Array.isArray(room.abacAttributes);
    }
    async executePreRoomCreatePrevent(room, read, http, persistence) {
        return false;
    }
}
exports.SecureFieldsTestApp = SecureFieldsTestApp;
